#from pylatexenc.latexencode import unicode_to_latex
from pylatexenc.latex2text import LatexNodes2Text
import glob
import os
import pydetex.pipelines

texts = glob.glob(r'C:\Users\Pheon\Documents\exercicematching\latex\*.tex')
for currenttext in texts:    
    with open(currenttext,'r',encoding='utf-8') as latex:
        text = pydetex.pipelines.simple(latex.read(),show_progress=True)#"z'-(1+a)(1+i)z+(1+a?)i=0 "#unicode_to_latex(latex.read())
    with open(r'C:\Users\Pheon\Documents\exercicematching\latextotext\latextotextoutput'+ os.path.basename(currenttext)+'.txt','w',encoding='utf-8') as output:
        output.write(text)    