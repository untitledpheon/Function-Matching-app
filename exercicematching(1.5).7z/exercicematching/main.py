
from tkinter import *
from tkinter import ttk
import tkinter as tk
import os
import glob
from pylatexenc.latex2text import LatexNodes2Text
import pydetex.pipelines
import Levenshtein
from ttkthemes import ThemedTk

gui = ThemedTk(theme='yaru')
input = (tk.Text(gui,height=10,width=75))

input.grid(row=0,column=0,padx=30,pady=30)
texts = glob.glob(r'C:\Users\Pheon\Documents\exercicematching\latextotext\latextotextoutput\*.txt')




def lookup():
    os.system('cls')
    
    biggestsimilarity = 0
    maybe = []
    for text in texts:
        userinput = pydetex.pipelines.simple(input.get('1.0','end')).replace(' ','')
        i = open(text,'r',encoding='utf-8')
        reference = i.read()
  

        parts = []
        for z in range(0,len(reference),len(userinput)):
             parts.append(reference[z:int(z+len(userinput))])
                 
       
        for y in parts:
            currentsimilarity = Levenshtein.ratio(userinput,y)
            if currentsimilarity > biggestsimilarity:
                print(y)
                biggestsimilarity = currentsimilarity
                biggestsimilarityfile = f'{round(biggestsimilarity,3)} === {os.path.basename(text)} ======== {y}' 
                maybe.append(f'{round(currentsimilarity,3)} ===  {os.path.basename(text).split('.')[0]}======== {y}') 


    maybe.pop() 
    maybe.reverse() 
    outputgui.delete('1.0',END)
    outputgui.insert(END , 'INPUTTED EQUATION: ' + userinput + '\n')
    outputgui.insert(END ,'______________________________________' + '\n')
    outputgui.insert(END ,biggestsimilarityfile + '\n')    
    outputgui.insert(END ,'______________________________________' + '\n')    
    for l in maybe:
        outputgui.insert(END ,l + '\n')
    
    

outputgui = tk.Text(gui)
outputgui.grid(row =2,column=0,padx=10,pady=10)
(ttk.Label(gui)).grid(row=3,column=0,pady=10)

button = (ttk.Button(gui,text='FIND EXERCISE',command = lookup)).grid(row=1,column=0)


gui.mainloop()