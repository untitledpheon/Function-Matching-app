
from tkinter import *
from tkinter import ttk
import tkinter as tk
import os
import glob
import Levenshtein
import random
from ttkthemes import ThemedTk

gui = ThemedTk(theme='yaru')
input = (tk.Text(gui,height=10,width=75))

input.grid(row=0,column=0,padx=30,pady=30)
texts = glob.glob(r'C:\Users\Pheon\Documents\exercicematching\latex\*.tex')
pdfs = glob.glob(r'C:\Users\Pheon\Documents\exercicematching\pdfs\*.pdf')

def getrandompdftesting():
    os.system(pdfs[random.randint(0,len(pdfs))])




def lookup():
    os.system('cls')
    
    biggestsimilarity = 0
    maybe = []
    for text in texts:
        userinput = input.get('1.0','end').replace('mathbf','').replace('{','').replace('}','').replace('bf','').replace(' ','').replace('mathrm','').replace('$','').replace('\\','').replace('sqrt','').replace('left','').replace('right','').replace('!','')
        i = open(text,'r',encoding='utf-8')
        reference = i.read().replace('mathbf','').replace('{','').replace('}','').replace('bf','').replace(' ','').replace('mathrm','').replace('$','').replace('\\','').replace('sqrt','').replace('left','').replace('right','').replace('!','')
        parts = []
        for z in range(0,len(reference),int(len(userinput))+ 5):
             parts.append(reference[z- 5:int(z+len(userinput))+ 5] )
        
        if reference.find(userinput) != -1:
                biggestsimilarityfile =(f'FOUND EXACT MATCH: \n {os.path.basename(text).split('.')[0]}')   
                maybe.clear()                  
                break    
        else:        
            for y in parts:
                currentsimilarity = Levenshtein.ratio(userinput,y)
                if currentsimilarity > biggestsimilarity:
                    biggestsimilarity = currentsimilarity
                    biggestsimilarityfile = f'COULDNT FIND EXACT MATCH HERE ARE THE CLOSEST: \n {round(biggestsimilarity,3)} === {os.path.basename(text).split('.')[0]} '#======== {y} 
                    maybe.append(f'{round(currentsimilarity,3)} ===  {os.path.basename(text).split('.')[0]}')#======== {y}') 
        

    print(userinput) 
    try:
        maybe.pop() 
        maybe.reverse() 
    except IndexError:
         pass    
    outputgui.delete('1.0',END)
    #outputgui.insert(END , 'INPUTTED EQUATION: ' + userinput + '\n')
    outputgui.insert(END ,'______________________________________' + '\n')
    outputgui.insert(END ,biggestsimilarityfile + '\n')    
    outputgui.insert(END ,'______________________________________' + '\n')    
    for l in maybe:
        outputgui.insert(END ,l + '\n')
    
    

outputgui = tk.Text(gui)
outputgui.grid(row =2,column=0,padx=10,pady=10)
(ttk.Label(gui)).grid(row=3,column=0,pady=10)

findexercicebutton = (ttk.Button(gui,text='FIND EXERCISE',command = lookup)).grid(row=1,column=0)
randompdfbutton =  (ttk.Button(gui,text='GETRANDOMPDF',command = getrandompdftesting)).grid(row=1,column=1,padx=10)


gui.mainloop()
