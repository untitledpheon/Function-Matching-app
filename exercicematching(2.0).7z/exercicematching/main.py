

import customtkinter as ctk
import os
import glob
import Levenshtein
import random


ctk.set_appearance_mode("System")
ctk.set_default_color_theme("blue")

gui = ctk.CTk()
gui.title('EXERCISE MATCHER')
#column1 = ctk.CTkLabel(gui).grid(row=0,column =0)
#column2 = ctk.CTkLabel(gui).grid(row=0,column =1)
#column3 = ctk.CTkLabel(gui).grid(row=0,column =2)

input = (ctk.CTkTextbox(gui,height=200,width=300))
input.grid(row=1,column=0,columnspan=2,padx=10,pady = 10)
texts = glob.glob(r'C:\Users\Pheon\Documents\exercicematching\latex\*.tex')
pdfs = glob.glob(r'C:\Users\Pheon\Documents\exercicematching\pdfs\*.pdf')


def getrandompdftesting():
    global currentrandompdf
    currentrandompdf = pdfs[random.randint(0,len(pdfs))]
    os.startfile(currentrandompdf)   
    return currentrandompdf

def gettex():
    os.startfile('C:\\Users\\Pheon\\Documents\\exercicematching\\latex\\' + os.path.basename(currentrandompdf).split('.')[0]+'.tex')     
    



def lookup():
    global biggestsimilaritypdf
    os.system('cls')
    
    biggestsimilarity = 0
    maybe = []
    for text in texts:
        userinput = input.get(1.0,'end-1c').replace('mathbf','').replace('{','').replace('}','').replace('bf','').replace(' ','').replace('mathrm','').replace('$','').replace('\\','').replace('sqrt','').replace('left','').replace('right','').replace('!','').replace('mathbb','').replace('(','').replace(')','').replace(',','').replace('scriptstyle','').replace('displaystyle','')
        with open(text,'r',encoding='utf-8') as i:
            reference = i.read().replace('mathbf','').replace('{','').replace('}','').replace('bf','').replace(' ','').replace('mathrm','').replace('$','').replace('\\','').replace('sqrt','').replace('left','').replace('right','').replace('!','').replace('mathbb','').replace('(','').replace(')','').replace(',','').replace(',','').replace('scriptstyle','').replace('displaystyle','')
        parts = []
        for z in range(0,len(reference),int(len(userinput))+ 5):
             parts.append(reference[z- 5:int(z+len(userinput))+ 5] )
        
        if reference.find(userinput) != -1:
                print(1)
                biggestsimilarityfile =(f'FOUND EXACT MATCH: \n {os.path.basename(text).split('.')[0]}')   
                biggestsimilaritypdf = 'C:\\Users\\Pheon\\Documents\\exercicematching\\pdfs\\' + os.path.basename(text).split('.')[0]+'.pdf'
                maybe.clear()                  
                break    
        else:        
            for y in parts:
                currentsimilarity = Levenshtein.ratio(userinput,y)
                if currentsimilarity > biggestsimilarity:
                    biggestsimilarity = currentsimilarity
                    biggestsimilarityfile = f'COULDNT FIND EXACT MATCH HERE ARE THE CLOSEST: \n {round(biggestsimilarity,3)} === {os.path.basename(text).split('.')[0]}'
                    biggestsimilaritypdf = 'C:\\Users\\Pheon\\Documents\\exercicematching\\pdfs\\' + os.path.basename(text).split('.')[0]+'.pdf'
                    v = y
                    print(reference.find(userinput))
                    maybe.append(f'{round(currentsimilarity,3)} ===  {os.path.basename(text).split('.')[0]} ') 
                    o = open(r'C:\Users\Pheon\Documents\exercicematching\output.txt','w',encoding='utf-8')
                    o.write(reference) 
                    o.close()            
    print(v)
    print(userinput) 
    try:
        maybe.pop() 
        maybe.reverse() 
    except IndexError:
         pass    
    outputgui.delete('1.0','end')
    #outputgui.insert('end' , 'INPUTTED EQUATION: ' + userinput + '\n')
    outputgui.insert('end' ,'______________________________________' + '\n')
    outputgui.insert('end' ,biggestsimilarityfile + '\n')    
    outputgui.insert('end' ,'______________________________________' + '\n')    
    for l in maybe:
        outputgui.insert('end' ,l + '\n')
 
def highestpdf():
    os.startfile(biggestsimilaritypdf)
   

outputgui = ctk.CTkTextbox(gui,height=200,width=500)
outputgui.grid(row =2,column=0,pady=10,columnspan=3,padx=10)
(ctk.CTkLabel(gui)).grid(row=3,column=0,pady=10)

findexercicebutton = (ctk.CTkButton(gui,text='FIND EXERCISE',command = lookup,width=40)).grid(row=1,column=2,ipady= 50,padx=10)




randompdfbutton =  (ctk.CTkButton(gui,text='GETRANDOMPDF',command = getrandompdftesting)).grid(row=3,column=0)
GETTEXbutton =  (ctk.CTkButton(gui,text='GETTEX',command = gettex)).grid(row=3,column=1)
biggestsimilaritypdfbutton =  (ctk.CTkButton(gui,text='GETBIGGESTSIMILRITYPDF',command = highestpdf)).grid(row=3,column=2)



gui.mainloop()
