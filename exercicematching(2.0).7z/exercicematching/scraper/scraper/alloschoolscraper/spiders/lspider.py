from typing import Iterable
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
import scrapy

class moutmadrisspider(scrapy.Spider):
    name = 'spider1'
    def start_requests(self):
        url= 'https://www.maths-inter.ma/sysma/lycee/2eme-annee-bac/sciences-exp/exams-nationaux/'
        yield scrapy.Request(url=url , callback=self.response_parser)
            
    
    def response_parser(self,response):
        for link in (response.xpath('//*[@id="post-5344"]/div/div/div[1]/div/div/div/div/div/div/div/div/a/@href').getall()):
                yield{
                    'link' : link
                }