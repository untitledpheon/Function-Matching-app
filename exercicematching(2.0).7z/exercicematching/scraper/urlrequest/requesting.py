import json 
import os
file = open('output.json',encoding='utf-8')
data = json.load(file)
for i in data:
    for l in list(i.values()):
        os.system(f'curl {l} --remote-name')